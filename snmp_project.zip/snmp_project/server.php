<?php
function getSnmp($ip, $community, $oidBase, $columnCount) {
    $result = array();
    for ($i = 1; $i <= $columnCount; $i++) {
        $result[] = snmp2_walk($ip, $community, $oidBase . "." . $i);
    }
    return $result;
}

function setSnmpValue($type, $value) {
    $ip = "127.0.0.1";
    $community = "private"; // ensure it's RW
    $typeMap = [
        "name" => ".1.3.6.1.2.1.1.5.0",
        "location" => ".1.3.6.1.2.1.1.6.0",
        "contact" => ".1.3.6.1.2.1.1.4.0"
    ];

    if (array_key_exists($type, $typeMap)) {
        snmp2_set($ip, $community, $typeMap[$type], 's', $value);
    }
}

$ip = "127.0.0.1";
$community = "public";

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $result = [];

    switch ($action) {
        case "system":
            $result = getSnmp($ip, $community, ".1.3.6.1.2.1.1", 6); // sysDescr to sysLocation
            break;
        
        case "tcp":

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $host = "127.0.0.1";
            $community = "public";
            $version = SNMP::VERSION_2C;

            if ($_POST['action'] === 'tcp') {
                $oidBase = "1.3.6.1.2.1.6.13.1"; // tcpConnTable
                $snmp = new SNMP($version, $host, $community);

                $tcpData = $snmp->walk($oidBase);
                $result = [];

                foreach ($tcpData as $oid => $value) {
                    $parts = explode('.', $oid);
                    $oidName = $parts[10] ?? 'unknown'; // index 10: 1.3.6.1.2.1.6.13.1.X...

                    // Extract IP and port
                    $ip = implode('.', array_slice($parts, 11, 4)); // 4 octets after index 10
                    $port = $parts[15] ?? 'unknown';

                    $result[] = [
                        $oid,
                        $ip,
                        $port
                    ];
                }

                $snmp->close();

                echo json_encode($result);
                exit;
            }
        }
        break;
        case "icmp":
            $result = getSnmp($ip, $community, ".1.3.6.1.2.1.5", 26); // ICMP stats
            break;
        case "set":
            if (isset($_POST['type']) && isset($_POST['value'])) {
                setSnmpValue($_POST['type'], $_POST['value']);
                echo "Updated successfully.";
                return;
            }
            break;
    }

    echo json_encode($result);
}
?>