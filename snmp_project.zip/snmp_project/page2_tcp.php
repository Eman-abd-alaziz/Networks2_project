<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TCP Connection Table</title>
    <script src="pipe.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #ffeef8, #f7f0ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: linear-gradient(145deg, #ffffff, #f9f0f7);
            padding: 40px 30px;
            border-radius: 25px;
            box-shadow: 0px 10px 30px rgba(200, 150, 200, 0.2);
            width: 100%;
            max-width: 800px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            font-size: 36px;
            color: #b04ba5;
            margin-bottom: 25px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 4px 10px rgba(180, 130, 180, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            font-size: 16px;
            color: #6a1b9a;
        }

        th {
            background-color: #f1e5f6;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f7f0f7;
        }

        tr:hover {
            background-color: #f0e0f4;
            cursor: pointer;
        }

        button {
            margin-top: 30px;
            padding: 12px 20px;
            background: linear-gradient(135deg, #f8d7f5, #e9d7f8);
            border: none;
            border-radius: 20px;
            color: #6a1b9a;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
        }

        button:hover {
            background: linear-gradient(135deg, #e1bee7, #d1c4e9);
            color: #4a148c;
            transform: scale(1.05);
        }

        .links {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 30px;
        }

        .links a {
            padding: 12px 18px;
            background: linear-gradient(135deg, #f8d7f5, #e9d7f8);
            border-radius: 20px;
            color: #8e24aa;
            font-weight: bold;
            text-decoration: none;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .links a:hover {
            background: linear-gradient(135deg, #e1bee7, #d1c4e9);
            color: #6a1b9a;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<div class="container">
    <h2>TCP Connection Table</h2>

    <button onclick="getSnmpData('tcp')">Get TCP Table</button>

    <table>
        <thead>
        <tr>
            <th>OID</th>
            <th>TCP Local Address</th>
            <th>TCP Local Port</th>
        </tr>
        </thead>
        <tbody id="table-body">
        <!-- Filled by JS -->
        </tbody>
    </table>

    <div class="links">
        <a href="page1_system.php">Back </a>
        <a href="page3_icmp.php"> Next </a>
    </div>
</div>
</body>
</html>
