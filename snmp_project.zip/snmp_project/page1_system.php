<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Group</title>
    <script src="pipe.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #ffeef8, #f7f0ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: linear-gradient(145deg, #ffffff, #f9f0f7);
            padding: 40px 30px;
            border-radius: 25px;
            box-shadow: 0px 10px 30px rgba(200, 150, 200, 0.2);
            width: 100%;
            max-width: 600px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            font-size: 34px;
            color: #b04ba5;
            margin-bottom: 35px;
            text-align: center;
        }

        .form-group {
            width: 100%;
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-weight: 600;
            color: #6a1b9a;
            margin-bottom: 8px;
            font-size: 16px;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px 16px;
            margin-top: 5px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #fdf9fd, #f7f0f7);
            box-shadow: 0px 4px 10px rgba(180, 130, 180, 0.15);
            font-size: 16px;
            color: #5c5c5c;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            outline: none;
            box-shadow: 0px 6px 15px rgba(180, 130, 180, 0.25);
            background: linear-gradient(135deg, #fff0f8, #f0f0ff);
        }

        ::placeholder {
            color: #b9a6bf;
            font-style: italic;
        }

        .btn-update {
            margin-top: 10px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #f8d7f5, #e9d7f8);
            border: none;
            border-radius: 20px;
            color: #6a1b9a;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 15px;
        }

        .btn-update:hover {
            background: linear-gradient(135deg, #e1bee7, #d1c4e9);
            color: #4a148c;
            transform: scale(1.05);
        }

        .links {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 30px;
        }

        .links a {
            background: linear-gradient(135deg, #f8d7f5, #e9d7f8);
            padding: 12px 18px;
            border-radius: 20px;
            color: #8e24aa;
            font-weight: bold;
            text-decoration: none;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .links a:hover {
            background: linear-gradient(135deg, #e1bee7, #d1c4e9);
            color: #6a1b9a;
            transform: scale(1.05);
        }
    </style>
</head>
<body onload="getSnmpData('system')">
<div class="container">
    <h2>System Group Info</h2>

    <div class="form-group">
        <label for="des">Description:</label>
        <input type="text" id="des" readonly placeholder="Description will appear here">
    </div>

    <div class="form-group">
        <label for="obj">Object ID:</label>
        <input type="text" id="obj" readonly placeholder="Object ID will appear here">
    </div>

    <div class="form-group">
        <label for="time">Uptime:</label>
        <input type="text" id="time" readonly placeholder="Uptime will appear here">
    </div>

    <div class="form-group">
        <label for="contact">Contact:</label>
        <input type="text" id="contact" placeholder="Enter contact info">
        <button class="btn-update" onclick="setSnmpData('contact')">Update</button>
    </div>

    <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" placeholder="Enter name">
        <button class="btn-update" onclick="setSnmpData('name')">Update</button>
    </div>

    <div class="form-group">
        <label for="location">Location:</label>
        <input type="text" id="location" placeholder="Enter location">
        <button class="btn-update" onclick="setSnmpData('location')">Update</button>
    </div>

    <div class="links">
        <a href="index.html"> Back Home</a>
        <a href="page2_tcp.php">Next </a>
    </div>
</div>
</body>
</html>
