function getSnmpData(type) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "server.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            const data = JSON.parse(xhr.responseText);
            if (type === "system") {
                updateSystem(data);
            } else {
                updateTable(data);
            }
        }
    };
    xhr.send("action=" + type);
}

function updateTable(data) {
    const tableBody = document.getElementById("table-body");
    tableBody.innerHTML = "";

    data.forEach(function (rowData) {
        const newRow = document.createElement("tr");
        rowData.forEach(function (cellData) {
            const newCell = document.createElement("td");
            newCell.textContent = cellData;
            newRow.appendChild(newCell);
        });
        tableBody.appendChild(newRow);
    });
}

function updateSystem(data) {
    const input = [
        document.getElementById("des"),
        document.getElementById("obj"),
        document.getElementById("time"),
        document.getElementById("contact"),
        document.getElementById("name"),
        document.getElementById("location"),
    ];

    for (let i = 0; i < input.length; i++) {
        const mod = String(data[i]).replace(String(data[i]).split(':')[0] + ": ", '');
        input[i].value = mod;
    }
}

function setSnmpData(type) {
    let value = "";
    if (type === "name") value = document.getElementById("name").value;
    if (type === "location") value = document.getElementById("location").value;
    if (type === "contact") value = document.getElementById("contact").value;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "server.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    const params = "action=set&type=" + type + "&value=" + encodeURIComponent(value);

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            if (xhr.responseText.includes("Updated successfully")) {
                alert("✅ تم التحديث بنجاح");
            } else {
                alert("❌ حدث خطأ أثناء التحديث");
            }
        }
    };
    xhr.send(params);
}

