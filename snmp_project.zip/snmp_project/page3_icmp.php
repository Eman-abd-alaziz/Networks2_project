<?php
$host = "127.0.0.1";
$community = "public";
$version = SNMP::VERSION_2C;
$oidICMP = '1.3.6.1.2.1.5';

// ICMP OID Names from MIB-II
function getICMPObjectNames() {
    return array(
        '1.3.6.1.2.1.5.1' => 'icmpInMsgs',
        '1.3.6.1.2.1.5.2' => 'icmpInErrors',
        '1.3.6.1.2.1.5.3' => 'icmpInDestUnreachs',
        '1.3.6.1.2.1.5.4' => 'icmpInTimeExcds',
        '1.3.6.1.2.1.5.5' => 'icmpInParmProbs',
        '1.3.6.1.2.1.5.6' => 'icmpInSrcQuenchs',
        '1.3.6.1.2.1.5.7' => 'icmpInRedirects',
        '1.3.6.1.2.1.5.8' => 'icmpInEchos',
        '1.3.6.1.2.1.5.9' => 'icmpInEchoReps',
        '1.3.6.1.2.1.5.10' => 'icmpInTimestamps',
        '1.3.6.1.2.1.5.11' => 'icmpInTimestampReps',
        '1.3.6.1.2.1.5.12' => 'icmpInAddrMasks',
        '1.3.6.1.2.1.5.13' => 'icmpInAddrMaskReps',
        '1.3.6.1.2.1.5.14' => 'icmpOutMsgs',
        '1.3.6.1.2.1.5.15' => 'icmpOutErrors',
        '1.3.6.1.2.1.5.16' => 'icmpOutDestUnreachs',
        '1.3.6.1.2.1.5.17' => 'icmpOutTimeExcds',
        '1.3.6.1.2.1.5.18' => 'icmpOutParmProbs',
        '1.3.6.1.2.1.5.19' => 'icmpOutSrcQuenchs',
        '1.3.6.1.2.1.5.20' => 'icmpOutRedirects',
        '1.3.6.1.2.1.5.21' => 'icmpOutEchos',
        '1.3.6.1.2.1.5.22' => 'icmpOutEchoReps',
        '1.3.6.1.2.1.5.23' => 'icmpOutTimestamps',
        '1.3.6.1.2.1.5.24' => 'icmpOutTimestampReps',
        '1.3.6.1.2.1.5.25' => 'icmpOutAddrMasks',
        '1.3.6.1.2.1.5.26' => 'icmpOutAddrMaskReps'
    );
}

function getICMPObjectNames2() {
    return array(
        'iso.3.6.1.2.1.5.1.0' => 'icmpInMsgs',
        'iso.3.6.1.2.1.5.2.0' => 'icmpInErrors',
        'iso.3.6.1.2.1.5.3.0' => 'icmpInDestUnreachs',
        'iso.3.6.1.2.1.5.4.0' => 'icmpInTimeExcds',
        'iso.3.6.1.2.1.5.5.0' => 'icmpInParmProbs',
        'iso.3.6.1.2.1.5.6.0' => 'icmpInSrcQuenchs',
        'iso.3.6.1.2.1.5.7.0' => 'icmpInRedirects',
        'iso.3.6.1.2.1.5.8.0' => 'icmpInEchos',
        'iso.3.6.1.2.1.5.9.0' => 'icmpInEchoReps',
        'iso.3.6.1.2.1.5.10.0' => 'icmpInTimestamps',
        'iso.3.6.1.2.1.5.11.0' => 'icmpInTimestampReps',
        'iso.3.6.1.2.1.5.12.0' => 'icmpInAddrMasks',
        'iso.3.6.1.2.1.5.13.0' => 'icmpInAddrMaskReps',
        'iso.3.6.1.2.1.5.14.0' => 'icmpOutMsgs',
        'iso.3.6.1.2.1.5.15.0' => 'icmpOutErrors',
        'iso.3.6.1.2.1.5.16.0' => 'icmpOutDestUnreachs',
        'iso.3.6.1.2.1.5.17.0' => 'icmpOutTimeExcds',
        'iso.3.6.1.2.1.5.18.0' => 'icmpOutParmProbs',
        'iso.3.6.1.2.1.5.19.0' => 'icmpOutSrcQuenchs',
        'iso.3.6.1.2.1.5.20.0' => 'icmpOutRedirects',
        'iso.3.6.1.2.1.5.21.0' => 'icmpOutEchos',
        'iso.3.6.1.2.1.5.22.0' => 'icmpOutEchoReps',
        'iso.3.6.1.2.1.5.23.0' => 'icmpOutTimestamps',
        'iso.3.6.1.2.1.5.24.0' => 'icmpOutTimestampReps',
        'iso.3.6.1.2.1.5.25.0' => 'icmpOutAddrMasks',
        'iso.3.6.1.2.1.5.26.0' => 'icmpOutAddrMaskReps'
    );
}

// SNMP connection
$snmp = new SNMP($version, $host, $community);

// Method 1: snmp2_get()
$icmpByGet = [];
foreach (getICMPObjectNames() as $oid => $name) {
    $value = @snmp2_get($host, $community, "$oid.0");
    if ($value !== false) {
        $icmpByGet[$oid] = $value;
    }
}

// Method 2: snmp2_walk()
$icmpByWalk = array();
$walkResult = $snmp->walk($oidICMP);
if ($walkResult !== false) {
    foreach ($walkResult as $oid => $value) {
        $icmpByWalk[$oid] = $value;
    }
}

$snmp->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ICMP Group Statistics</title>
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #ffeef8, #f7f0ff); /* تدرج اللون البنفسجي الفاتح */
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            margin-top: 40px;
            font-size: 32px;
            color: #b04ba5; /* لون العنوان البنفسجي الفاتح */
        }
        .row {
            margin: 20px auto;
            max-width: 1000px;
            display: flex;
            justify-content: space-between;
        }
        .column {
            width: 48%;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: white;
            box-shadow: 0px 10px 30px rgba(200, 150, 200, 0.2); /* إضافة ظل خفيف */
            border-radius: 10px; /* زوايا دائرية */
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            color: #6a1b9a; /* لون النص البنفسجي */
        }
        th {
            background-color: #f1e5f6; /* لون رأس الجدول */
        }
        tr:nth-child(even) {
            background-color: #f7f0f7; /* لون الصفوف الزوجية */
        }
        tr:hover {
            background-color: #f0e0f4; /* تأثير عند التمرير على الصف */
            cursor: pointer;
        }
        a {
            display: block;
            text-align: center;
            background: linear-gradient(135deg, #f8d7f5, #e9d7f8); /* تدرج اللون للبوتون */
            color: #6a1b9a; /* لون النص البنفسجي */
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            width: 200px;
            margin: 30px auto;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        a:hover {
            background: linear-gradient(135deg, #e1bee7, #d1c4e9); /* تأثير عند التمرير */
            color: #4a148c; /* تغيير اللون عند التمرير */
        }
    </style>
</head>
<body>

<h2>ICMP Group Statistics</h2>

<div class="row">
    <!-- Table By Get -->
    <div class="column">
        <table>
            <caption>Table By Get</caption>
            <tr>
                <th>OID</th>
                <th>Name</th>
                <th>Value</th>
            </tr>
            <?php foreach ($icmpByGet as $oid => $value):
                $name = getICMPObjectNames()[$oid] ?? 'Unknown';
                $oidEnd = explode('.', $oid);
                $last = end($oidEnd);
                ?>
                <tr>
                    <td><?php echo $last; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $value; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <!-- Table By Walk -->
    <div class="column">
        <table>
            <caption>Table By Walk</caption>
            <tr>
                <th>OID</th>
                <th>Name</th>
                <th>Value</th>
            </tr>
            <?php foreach ($icmpByWalk as $oid => $value):
                $name = isset(getICMPObjectNames2()[$oid]) ? getICMPObjectNames2()[$oid] : 'Unknown';
                if ($name === 'Unknown') {
                    break;
                }
                $valParts = explode(': ', $value);
                $cleanValue = end($valParts);
                $oidParts = explode('.', $oid);
                $id = $oidParts[count($oidParts) - 2];
                ?>
                <tr>
                    <td><?php echo $id; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $cleanValue; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

<a href="index.html">Back to Home</a>

</body>
</html>
