import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import org.json.JSONObject;

public class SNMPClientGUI {

    private JTextArea textAreaSystem;
    private JTextArea textAreaTCP;
    private JTextArea textAreaICMP;
    private JButton getSystemDataButton, getTCPDataButton, getICMPDataButton;

    public SNMPClientGUI() {
        JFrame frame = new JFrame("SNMP Client");
        JTabbedPane tabbedPane = new JTabbedPane();

        // Tab 1: System Group
        JPanel systemPanel = new JPanel();
        systemPanel.setLayout(new BorderLayout());
        textAreaSystem = new JTextArea(20, 40);
        textAreaSystem.setEditable(false);
        systemPanel.add(new JScrollPane(textAreaSystem), BorderLayout.CENTER);

        getSystemDataButton = new JButton("Get System Data");
        getSystemDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String response = fetchSNMPData("http://localhost/getSystemData.php");
                if (response != null) {
                    JSONObject jsonResponse = new JSONObject(response);
                    textAreaSystem.setText(jsonResponse.toString(4)); // Pretty print
                }
            }
        });
        systemPanel.add(getSystemDataButton, BorderLayout.SOUTH);

        // Tab 2: TCP Table
        JPanel tcpPanel = new JPanel();
        tcpPanel.setLayout(new BorderLayout());
        textAreaTCP = new JTextArea(20, 40);
        textAreaTCP.setEditable(false);
        tcpPanel.add(new JScrollPane(textAreaTCP), BorderLayout.CENTER);

        getTCPDataButton = new JButton("Get TCP Table");
        getTCPDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String response = fetchSNMPData("http://localhost/getTCPData.php");
                if (response != null) {
                    JSONObject jsonResponse = new JSONObject(response);
                    textAreaTCP.setText(jsonResponse.toString(4)); // Pretty print
                }
            }
        });
        tcpPanel.add(getTCPDataButton, BorderLayout.SOUTH);

        // Tab 3: ICMP Statistics
        JPanel icmpPanel = new JPanel();
        icmpPanel.setLayout(new BorderLayout());
        textAreaICMP = new JTextArea(20, 40);
        textAreaICMP.setEditable(false);
        icmpPanel.add(new JScrollPane(textAreaICMP), BorderLayout.CENTER);

        getICMPDataButton = new JButton("Get ICMP Stats");
        getICMPDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String response = fetchSNMPData("http://localhost/getICMPData.php");
                if (response != null) {
                    JSONObject jsonResponse = new JSONObject(response);
                    textAreaICMP.setText(jsonResponse.toString(4)); // Pretty print
                }
            }
        });
        icmpPanel.add(getICMPDataButton, BorderLayout.SOUTH);

        // Add tabs to the tabbed pane
        tabbedPane.addTab("System Group", systemPanel);
        tabbedPane.addTab("TCP Table", tcpPanel);
        tabbedPane.addTab("ICMP Statistics", icmpPanel);

        // Add tabbedPane to the frame
        frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Method to fetch SNMP data from the PHP server
    public static String fetchSNMPData(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Main method to run the client GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SNMPClientGUI();
            }
        });
    }
}
