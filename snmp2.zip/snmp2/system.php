<?php
$community = "public";
$ip = "127.0.0.1";
$version = "2c";

$systemOIDs = [
    "1.3.6.1.2.1.1.1.0",  // sysDescr
    "1.3.6.1.2.1.1.2.0",  // sysObjectID
    "1.3.6.1.2.1.1.3.0",  // sysUpTime
    "1.3.6.1.2.1.1.4.0",  // sysContact
    "1.3.6.1.2.1.1.5.0",  // sysName
    "1.3.6.1.2.1.1.6.0"   // sysLocation
];

$fieldNames = [
    "sysDescr",
    "sysObjectID",
    "sysUpTime",
    "sysContact",
    "sysName",
    "sysLocation"
];

$result = [];

for ($i = 0; $i < count($systemOIDs); $i++) {
    $value = @snmp2_get($ip, $community, $systemOIDs[$i]);
    if ($value !== false) {
        $cleanValue = preg_replace('/^[^:]+:\s*/', '', $value);
        $cleanValue = trim($cleanValue);

        // تحويل القيم الرقمية لأرقام حقيقية
        if (is_numeric($cleanValue)) {
            $result[$fieldNames[$i]] = (strpos($cleanValue, '.') !== false) ? floatval($cleanValue) : intval($cleanValue);
        } else {
            $result[$fieldNames[$i]] = $cleanValue;
        }
    } else {
        $result[$fieldNames[$i]] = "Error fetching data.";
    }
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>
