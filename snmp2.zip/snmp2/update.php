<?php
// إعدادات الاتصال بـ SNMP
$community = "private";  // لاحظ هنا: تحتاج Community Read-Write، غالبًا يكون "private"
$ip = "127.0.0.1";       
$version = "2c";         

// تحقق أن الحقول المطلوبة موجودة بالطلب
if (isset($_GET['field']) && isset($_GET['value'])) {
    $field = $_GET['field'];
    $newValue = $_GET['value'];

    // تعيين OID حسب الحقل
    $oids = [
        "sysContact" => "1.3.6.1.2.1.1.4.0",
        "sysName"    => "1.3.6.1.2.1.1.5.0",
        "sysLocation"=> "1.3.6.1.2.1.1.6.0"
    ];

    if (array_key_exists($field, $oids)) {
        $oid = $oids[$field];

        // إرسال SNMP SET
        $result = @snmp2_set($ip, $community, $oid, "s", $newValue);

        if ($result !== false) {
            $response = ["status" => "success", "message" => "$field updated successfully."];
        } else {
            $response = ["status" => "error", "message" => "Failed to update $field."];
        }
    } else {
        $response = ["status" => "error", "message" => "Invalid field name."];
    }
} else {
    $response = ["status" => "error", "message" => "Missing parameters."];
}

// إرسال الرد بشكل JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
