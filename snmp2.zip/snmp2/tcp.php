<?php
$ip = "localhost";
$community = "public";

header('Content-Type: application/json');

// OIDs المطلوبة
$baseOid = "1.3.6.1.2.1.6.13.1";
$oids = [
    "state" => "$baseOid.1", // tcpConnState
    "localAddress" => "$baseOid.2", // tcpConnLocalAddress
    "localPort" => "$baseOid.3", // tcpConnLocalPort
    "remoteAddress" => "$baseOid.4", // tcpConnRemAddress
    "remotePort" => "$baseOid.5", // tcpConnRemPort
];

// اجلب بيانات كل OID
$data = [];
foreach ($oids as $key => $oid) {
    $result = @snmpwalk($ip, $community, $oid);

    if ($result === false) {
        echo json_encode([
            "status" => "error",
            "message" => "SNMP walk failed for $key"
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $cleaned = [];
    foreach ($result as $entry) {
        $cleanEntry = preg_replace('/^[^:]+:\s*/', '', $entry);
        $cleanEntry = trim($cleanEntry);
        $cleaned[] = $cleanEntry;
    }

    $data[$key] = $cleaned;
}

// تأكد أن كل النتائج نفس الطول
$count = count($data['state']);
foreach ($data as $key => $list) {
    if (count($list) !== $count) {
        echo json_encode([
            "status" => "error",
            "message" => "Mismatched SNMP data lengths"
        ], JSON_PRETTY_PRINT);
        exit;
    }
}

// ركب البيانات في مصفوفة اتصالات
$connections = [];
for ($i = 0; $i < $count; $i++) {
    $connections[] = [
        "state" => intval($data['state'][$i]),
        "localAddress" => $data['localAddress'][$i],
        "localPort" => intval($data['localPort'][$i]),
        "remoteAddress" => $data['remoteAddress'][$i],
        "remotePort" => intval($data['remotePort'][$i]),
    ];
}

// أرجع النتيجة
echo json_encode($connections, JSON_PRETTY_PRINT);
?>
