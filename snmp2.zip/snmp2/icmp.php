<?php
$community = "public";
$ip = "127.0.0.1";
$version = "2c";

$icmpBaseOid = "1.3.6.1.2.1.5";

$icmpData = @snmp2_walk($ip, $community, $icmpBaseOid);

$result = [];

if ($icmpData !== false) {
    foreach ($icmpData as $entry) {
        $cleanEntry = preg_replace('/^[^:]+:\s*/', '', $entry);
        $cleanEntry = trim($cleanEntry);

        if (is_numeric($cleanEntry)) {
            $result[] = (strpos($cleanEntry, '.') !== false) ? floatval($cleanEntry) : intval($cleanEntry);
        } else {
            $result[] = $cleanEntry;
        }
    }
} else {
    $result[] = "Error fetching ICMP statistics.";
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>
